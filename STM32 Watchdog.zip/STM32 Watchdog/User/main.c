#include "misc.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_iwdg.h"
#include "stm32f10x_wwdg.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_exti.h"
#include "utils.h"
#include "usart.h"
#include "stdio.h"
static u8 WWDG_CNT=0x7f;     /*Save the WWDG counter settings, the default is the largest */
void IWDG_setup(void);
void WWDG_setup(u8 tr,u8 wr,u32 fprer);
void WWDG_Reload_DownCounter(void);
//#define USE_IWDG
int main(void)
{
	Usart1Init(115200);
	setup_delay_timer(TIM2);
#ifdef USE_IWDG
	IWDG_setup();
	printf("Start IWDG demo code by Hoang Loc\r\n");
#else
	printf("Start WWDG demo code by Hoang Loc\r\n");
	WWDG_setup(0x7F,0x7F,WWDG_Prescaler_8); // kh?i t?o window watchdog
#endif	
	while(1)
	{		
#ifdef USE_IWDG
		IWDG_ReloadCounter(); //Use to reload -> prevent reset
		delay_ms(900);
#else
	 delay_ms(5);
	 WWDG_Reload_DownCounter(); // reload l?i counter
#endif
	}
}
void USART1_IRQHandler(void)
{
	char ch;
	if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
  {
    ch = (uint8_t)USART_ReceiveData(USART1);   
		if(ch == 'a') while(1){}
  }
}

void IWDG_setup(void)
{
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	IWDG_SetPrescaler(IWDG_Prescaler_256); //Period = 256/LSI = 256/40Khz = 6,4ms
	IWDG_SetReload(150);  //Reload every 150 * 6.4ms = 960ms
	IWDG_ReloadCounter(); //Use to reload -> prevent reset
	IWDG_Enable();
}
void WWDG_setup(u8 tr,u8 wr,u32 fprer)
{
	RCC_APB2PeriphClockCmd(RCC_APB1Periph_WWDG,ENABLE); //Enable Window watchdog 
	NVIC_InitTypeDef NVIC_InitStructure;
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);					
	NVIC_Init(&NVIC_InitStructure);
	NVIC_InitStructure.NVIC_IRQChannel = WWDG_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	

  WWDG_SetPrescaler(fprer); /*Set the IWDG pre frequency value*/
  WWDG_SetWindowValue(wr);    /*Settings window value*/

  WWDG_CNT=tr&WWDG_CNT; /* The initialization of WWDG_CNT */
  WWDG_Enable(WWDG_CNT);    /*Enable the watchdog, the         set the counter */
  WWDG_ClearFlag();    /*Remove pre wakeup interrupt flag*/

  
  WWDG_EnableIT(); /* Open the window watchdog interrupt */
}
void WWDG_IRQHandler()
{
	 WWDG_SetCounter(0x7f); // reload WWDG counter
	 WWDG_ClearFlag(); // clear EWI interrupt flag
}
void WWDG_Reload_DownCounter(void)
{
	WWDG_SetCounter(WWDG_CNT);
}