/*
 * usart.c code by lochoangvan@gmail.com 
 * 
 */
#include "usart.h"
#include "misc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_usart.h"
#include "stm32f10x_dma.h"
#include <string.h>
#include <stdio.h>
#define USE_USART1_INTERRUPT  //Define to use interrupt USART1
int fputc(int ch, FILE *f)
{
  USART_SendData(USART1, (unsigned char) ch);
  while (!(USART1->SR & USART_FLAG_TXE));
  return (ch);
}
void Usart1Init(unsigned int speed)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	USART_ClockInitTypeDef USART_InitClockStructure;
	 /* Enable GPIOA and USART1 clock */
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE );
#ifdef USE_USART1_INTERRUPT
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);										//USE group 4
		NVIC_InitTypeDef NVIC_InitStructure;
		NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn; 
		NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
		NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init( &NVIC_InitStructure );
#endif	
		/* Configure USART1 Rx (PA10) as input floating */
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
		GPIO_Init( GPIOA, &GPIO_InitStructure );

		/* Configure USART1 Tx (PA9) as alternate function push-pull */
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_Init( GPIOA, &GPIO_InitStructure );

		USART_InitStructure.USART_BaudRate = speed;
		USART_InitStructure.USART_WordLength = USART_WordLength_8b;
		USART_InitStructure.USART_StopBits = USART_StopBits_1;
		USART_InitStructure.USART_Parity = USART_Parity_No ;
		USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
		USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
		USART_InitClockStructure.USART_Clock = USART_Clock_Disable;
		USART_InitClockStructure.USART_CPOL = USART_CPOL_Low;
		USART_InitClockStructure.USART_CPHA = USART_CPHA_2Edge;
		USART_InitClockStructure.USART_LastBit = USART_LastBit_Disable;

		USART_Init( USART1, &USART_InitStructure );
		USART_ClockInit( USART1, &USART_InitClockStructure);
#ifdef USE_USART1_INTERRUPT
		USART_ITConfig( USART1, USART_IT_RXNE, ENABLE );											//Enable RX interrupt 
#endif
		USART_DMACmd( USART1, USART_DMAReq_Rx , ENABLE );	
		USART_Cmd( USART1, ENABLE );
}

void Usart1PutChar(char ch)
{
  USART_SendData(USART1, (unsigned char) ch);
  while (!(USART1->SR & USART_FLAG_TXE));
}
void USART1PutString( const char *pcString )
{
	while(*pcString != '\0')
		{
			USART_SendData(USART1, *pcString);
			while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
			pcString++;
		}
}

//USART2 config
void Usart2Init(unsigned int speed)
{   
	  USART_InitTypeDef USART_InitStructure;
	 																	// Configure the NVIC (nested vector interrupt controller)
	  GPIO_InitTypeDef GPIO_InitStructure;
	  USART_ClockInitTypeDef USART_InitClockStructure;
		 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    /* Enable UART clock */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
#ifdef USE_USART2_INTERRUPT
	  NVIC_InitTypeDef NVIC_InitStructure; 
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;  								  // we want to configure the USART1 interrupts
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;          // this sets the priority group of the USART1 interrupts
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;                     // the USART1 interrupts are globally enabled
    NVIC_Init(&NVIC_InitStructure);
#endif  
    // USART2 Tx (PA2)
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
		// USART2  Tx(PA3)
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // USART2
    USART_InitStructure.USART_BaudRate = speed;
		USART_InitStructure.USART_WordLength = USART_WordLength_8b;
		USART_InitStructure.USART_StopBits = USART_StopBits_1;
		USART_InitStructure.USART_Parity = USART_Parity_No ;
		USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
		USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
		USART_InitClockStructure.USART_Clock = USART_Clock_Disable;
		USART_InitClockStructure.USART_CPOL = USART_CPOL_Low;
		USART_InitClockStructure.USART_CPHA = USART_CPHA_2Edge;
		USART_InitClockStructure.USART_LastBit = USART_LastBit_Disable;
    USART_Init(USART2, &USART_InitStructure);
		USART_ClockInit( USART2, &USART_InitClockStructure);
#ifdef USE_USART2_INTERRUPT
		USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
#endif
    // Enable usart
    USART_Cmd(USART2, ENABLE);

}

void Usart2PutChar(char ch)
{
  USART_SendData(USART2, (char) ch);
  while (!(USART2->SR & USART_FLAG_TXE));
}
void USART2PutString(const char *pcString )
{
	while(*pcString != '\0')
		{
			USART_SendData(USART2, *pcString);
			while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
			pcString++;
		}
}

void Usart3Init(unsigned int speed)
{
	 GPIO_InitTypeDef GPIO_InitStructure;
	 USART_InitTypeDef USART_InitStructure;
	 									           // Configure the NVIC (nested vector interrupt controller)
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3,ENABLE);
#ifdef USE_USART3_INTERRUPT
	  // NVIC
		NVIC_InitTypeDef NVIC_InitStructure; 
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;   							 // we want to configure the USART1 interrupts
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;    	   // this sets the priority group of the USART1 interrupts
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;      							 // the USART1 interrupts are globally enabled
    NVIC_Init(&NVIC_InitStructure);
#endif
    // USART3  Tx (PB10)
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
		// USART3 RX (PB10)
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    // USART3
    USART_InitStructure.USART_BaudRate = speed;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;

    USART_Init(USART3, &USART_InitStructure);
#ifdef USE_USART3_INTERRUPT
    // Enable interrupts
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);
#endif
    // Enable usart
    USART_Cmd(USART3, ENABLE);
}
void Usart3PutChar(char ch)
{
  USART_SendData(USART3, (char) ch);
  while (!(USART3->SR & USART_FLAG_TXE));
}
void USART3PutString(const char *pcString )
{
	while(*pcString != '\0')
		{
			USART_SendData(USART3, *pcString);
			while(USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET);
			pcString++;
		}
}
