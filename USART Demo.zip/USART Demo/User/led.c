#include "led.h"

void LED_ON(unsigned char led)
{
	switch(led)
	{
		case 1: GPIO_SetBits(LEDPORT,LED1);break;
		case 2: GPIO_SetBits(LEDPORT,LED2);break;
		case 3: GPIO_SetBits(LEDPORT_1,LED3);break;
		case 4: GPIO_SetBits(LEDPORT_1,LED4);break;
	}
}
void LED_OFF(unsigned char led)
{
	switch(led)
	{
		case 1: GPIO_ResetBits(LEDPORT,LED1);break;
		case 2: GPIO_ResetBits(LEDPORT,LED2);break;
		case 3: GPIO_ResetBits(LEDPORT_1,LED3);break;
		case 4: GPIO_ResetBits(LEDPORT_1,LED4);break;
	}
}
void LED_ALL_ON(void)
{
	GPIO_SetBits(LEDPORT,LED1|LED2);
	GPIO_SetBits(LEDPORT_1,LED3|LED4);
}
void LED_ALL_OFF(void)
{
	GPIO_ResetBits(LEDPORT,LED1|LED2);
	GPIO_ResetBits(LEDPORT_1,LED3|LED4);
}
