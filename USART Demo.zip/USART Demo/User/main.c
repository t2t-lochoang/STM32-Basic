#include "misc.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "led.h"
#include "usart.h"
void LED_Configuration(void);
void Delay(unsigned int tick);

int main(void)
{
	LED_Configuration();
	Usart1Init(115200);
	while(1)
	{	
		
	}
 return 0;
}
void Delay(unsigned int tick)
{
	while(tick) tick--;
}
void LED_Configuration(void)
{
	RCC_APB2PeriphClockCmd(LEDPORTCLK|LEDPORTCLK_1,ENABLE);	//ENABLE CLOCK cho GPIOC va GPIOD
	RCC_APB2PeriphClockCmd(BUTTONPORTCLOCK,ENABLE);	   
	GPIO_InitTypeDef GPIO_InitStructure;										
  GPIO_InitStructure.GPIO_Pin = LED1|LED2;		
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;				//Output, tro keo
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;				//Clock GPIO 50Mhz
  GPIO_Init(LEDPORT, &GPIO_InitStructure);								//Cai dat GPIOC

	GPIO_InitStructure.GPIO_Pin = LED3|LED4;								//Cai dat GPIOD
	GPIO_Init(LEDPORT_1, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = BUTTON1|BUTTON2|BUTTON3|BUTTON4;		
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;		 //Input floating
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;				 //Clock GPIO 50Mhz
  GPIO_Init(BUTTONPORT, &GPIO_InitStructure);							 //Cai dat GPIOE
}
