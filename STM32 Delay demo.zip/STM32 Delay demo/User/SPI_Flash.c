/********************(C)COPYRIGHT 2010 lochoangvan@gmail.com********************

* Description        : bootloader by HoangLoc
Guide: 1. Option taget Choose device ex:
*/
/* Includes ------------------------------------------------------------------*/

#include "stm32f10x.h"
#include "SPI_Flash.h"
#include "stm32f10x_spi.h"
#define Sector_Size 256      //256Byte
#define Total_Sector 32        //Total sector of M25P16
#define Total_Page 8192 				//
u8 first_write = 0;
u8 old_address;
void FlashReadID(u8 *Data)
{
	u8 i;
	Select_Flash();	
  	SPI_Flash_SendByte(0x9F);
  	for(i = 0; i < 4; i++)
  	{
  		Data[i] = SPI_Flash_ReadByte();
  	}
  	NotSelect_Flash();	
}

/*******************************************************************************
* Function Name  : SPI_FLASH_Init
* Description    : Initializes the peripherals used by the SPI FLASH driver.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SPI_Flash_Init(void)
{
  SPI_InitTypeDef  SPI_InitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;
   
  /* Enable SPI2 GPIOA clocks */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1 ,ENABLE);
  RCC_APB2PeriphClockCmd(SPI_RCC_PORT, ENABLE);	 

  GPIO_InitStructure.GPIO_Pin = C_PIN | Q_PIN | D_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(SPI_GPIO_PORT, &GPIO_InitStructure);

  /* Configure PB.12 as Output push-pull, used as Flash Chip select */
  GPIO_InitStructure.GPIO_Pin = CS_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(SPI_GPIO_PORT, &GPIO_InitStructure);


  /* Deselect the FLASH: Chip Select high */
  NotSelect_Flash();

    /* SPI1 configuration */
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;
  SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;
  SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4;
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  SPI_InitStructure.SPI_CRCPolynomial = 7;
  SPI_Init(SPI1, &SPI_InitStructure);
  SPI_Cmd(SPI1, ENABLE);   
}


/*******************************************************************************
* Function Name  : SPI_FLASH_ReadByte
* Description    : Reads a byte from the SPI Flash.
*                  This function must be used only if the Start_Read_Sequence
*                  function has been previously called.
* Input          : None
* Output         : None
* Return         : Byte Read from the SPI Flash.
*******************************************************************************/
u8 SPI_Flash_ReadByte(void)	   
{
  return (SPI_Flash_SendByte(Dummy_Byte));
}

/*******************************************************************************
* Function Name  : SPI_FLASH_SendByte
* Description    : Sends a byte through the SPI interface and return the byte 
*                  received from the SPI bus.
* Input          : byte : byte to send.
* Output         : None
* Return         : The value of the received byte.
*******************************************************************************/
u8 SPI_Flash_SendByte(u8 byte)	
{
  /* Loop while DR register in not emplty */
  while(SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET);
  //NotSelect_Flash();  while(1);
  /* Send byte through the SPI2 peripheral */
  SPI_I2S_SendData(SPI1, byte);

  /* Wait to receive a byte */
  while(SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);

  /* Return the byte read from the SPI bus */
  return SPI_I2S_ReceiveData(SPI1);
}

void FlashPageEarse(u16 page) 
{	

  FlashWaitBusy();
  Select_Flash(); 
  SPI_Flash_SendByte(0X06);	
  NotSelect_Flash(); 

  FlashWaitBusy();
  Select_Flash(); 
  SPI_Flash_SendByte(SE); 
  SPI_Flash_SendByte((page & 0xFF0000) >> 16);
  SPI_Flash_SendByte((page & 0xFF00) >> 8);
  SPI_Flash_SendByte(page & 0xFF);
  NotSelect_Flash(); 

}
void FlashWaitBusy(void)
{

  u8 FLASH_Status = 0;

  Select_Flash();	
  SPI_Flash_SendByte(RDSR);
  do
  {
    FLASH_Status = SPI_Flash_SendByte(Dummy_Byte);
  }
  while ((FLASH_Status & WIP_Flag) == SET); 
  NotSelect_Flash();	   

}
/*Read array from flash*/
void M25P16_buf_ToRam(u8 buffer[],u32 start_address,u16 length)
{
	unsigned int i;
		FlashWaitBusy(); 
	
		Select_Flash();		
    SPI_Flash_SendByte(0X03);
    SPI_Flash_SendByte((start_address & 0xFF0000) >> 16);
    SPI_Flash_SendByte((start_address & 0xFF00) >> 8);
    SPI_Flash_SendByte(start_address & 0xFF);
  	for (i=0;i<length;i++)
		{
			buffer[i] = SPI_Flash_ReadByte();
		}
		NotSelect_Flash();
}
/*Write array to flash*/
void M25P16_RamTo_buf(u8 buffer[],u32 start_address,u16 length)
{
  unsigned int i;
	u32 New_Sec,sec_old,sec_new;
	sec_old = start_address/Sector_Size;           //Number of Current sector
	sec_new = (start_address+length)/Sector_Size;  //Number of Sector at new length 
	if(sec_old != sec_new||first_write == 0||old_address == start_address)       //Check if new data is locate at new Sector address
	{
		first_write = 1;
		New_Sec = start_address + length;            //Caculate locate of New_Sector
		FlashPageEarse(New_Sec);                     //Erase new Sector
	}
	old_address = start_address;
  FlashWaitBusy();
  Select_Flash(); 
  SPI_Flash_SendByte(0X06);	
  NotSelect_Flash(); 
  FlashWaitBusy();
	
  Select_Flash(); 
  SPI_Flash_SendByte(0X02);	
  SPI_Flash_SendByte((start_address & 0xFF0000) >> 16);
  SPI_Flash_SendByte((start_address & 0xFF00) >> 8);
  SPI_Flash_SendByte(start_address & 0xFF);
  for (i=0;i<length;i++) SPI_Flash_SendByte(buffer[i]);
  NotSelect_Flash();
}

