#ifndef _SPI_FLASH_H_
#define _SPI_FLASH_H_  1
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"


#define FLASH_CHREAD                  0x0B
#define FLASH_CLREAD                  0x03
#define FLASH_PREAD	                  0xD2

#define FLASH_BUFWRITE1               0x84  
#define FLASH_IDREAD                  0x9F
#define FLASH_STATUS                  0xD7	  
#define PAGE_ERASE                    0x81
#define PAGE_READ                     0xD2
#define MM_PAGE_TO_B1_XFER            0x53				 
#define BUFFER_2_WRITE                0x87					 
#define B2_TO_MM_PAGE_PROG_WITH_ERASE 0x86	

#define BUFFER_1_WRITE                0x84 
#define BUFFER_2_WRITE                0x87  
#define BUFFER_1_READ                 0xD4
#define BUFFER_2_READ                 0xD6  
#define B1_TO_MM_PAGE_PROG_WITH_ERASE 0x83  
#define B2_TO_MM_PAGE_PROG_WITH_ERASE 0x86  
#define MM_PAGE_TO_B1_XFER            0x53 
#define MM_PAGE_TO_B2_XFER            0x55  
#define PAGE_ERASE                    0x81  
#define SECTOR_ERASE                  0x7C  
#define READ_STATE_REGISTER           0xD7 


/* Private typedef -----------------------------------------------------------*/
#define SPI_FLASH_PageSize    0x100

/* Private define ------------------------------------------------------------*/
#define WRITE      0x02  /* Write to Memory instruction */
#define WRSR       0x01  /* Write Status Register instruction */
#define WREN       0x06  /* Write enable instruction */

#define READ       0x03  /* Read from Memory instruction */
#define RDSR       0x05  /* Read Status Register instruction  */
#define RDID       0x9F  /* Read identification */
#define SE         0xD8  /* Sector Erase instruction */
#define BE         0xC7  /* Bulk Erase instruction */

#define WIP_Flag   0x01  /* Write In Progress (WIP) flag */
#define Dummy_Byte 0xA5


#define SPI_RCC_PORT  RCC_APB2Periph_GPIOA
#define SPI_GPIO_PORT GPIOA
#define CS_PIN        GPIO_Pin_4
#define Q_PIN         GPIO_Pin_6
#define D_PIN			    GPIO_Pin_7
#define C_PIN         GPIO_Pin_5
//#define Dummy_Byte 0xA5

/* Select SPI FLASH: ChipSelect pin low  */
#define Select_Flash()     GPIO_ResetBits(SPI_GPIO_PORT, CS_PIN)
/* Deselect SPI FLASH: ChipSelect pin high */
#define NotSelect_Flash()    GPIO_SetBits(SPI_GPIO_PORT, CS_PIN)



void SPI_Flash_Init(void);
u8 SPI_Flash_ReadByte(void);
u8 SPI_Flash_SendByte(u8 byte);
void FlashPageEarse(u16 page);
void FlashPageRead(u16 page,u8 *Data);
void FlashPageWrite(u16 page,u8 *Data);
void FlashWaitBusy(void);
void M25P16_buf_ToRam(u8 buffer[],u32 start_address,u16 length);
void M25P16_RamTo_buf(u8 buffer[],u32 start_address,u16 length);	 





#endif


