#include "stdio.h"
#include "misc.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_usart.h"
#include "utils.h"
#include "SysTick.h"
#include "usart.h"

//#define USE_TIMER
int main(void)
{
	#ifdef USE_TIMER
	setup_delay_timer(TIM2);
	#else
	SysTick_Configuration();
	#endif
	Usart1Init(115200);
	printf("Delay demo code by Hoang Loc\r\n");
	while(1)
	{		
		#ifdef USE_TIMER
		printf("Delay use Timer\r\n");
		delay_ms_2(1000);         //Delay 1 second use Timer 2
		#else
		printf("Delay use System Tick\r\n");
		SysTick_DelayMs(1000);    //Delay 1 second use System Tick
		#endif
	}
 return 0;
}

