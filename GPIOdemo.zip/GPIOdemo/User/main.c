#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
void Delay(unsigned int tick);
//Define for LED
#define LED1 						GPIO_Pin_6			
#define LED2 						GPIO_Pin_7
#define LED3 						GPIO_Pin_6
#define LED4 						GPIO_Pin_13

#define LEDPORT					GPIOC
#define LEDPORT_1				GPIOD
#define LEDPORTCLK			RCC_APB2Periph_GPIOC
#define LEDPORTCLK_1		RCC_APB2Periph_GPIOD
//Define for BUTTON
#define BUTTON1 				GPIO_Pin_2			
#define BUTTON2 				GPIO_Pin_3
#define BUTTON3 				GPIO_Pin_4
#define BUTTON4 				GPIO_Pin_5

#define BUTTONPORT			GPIOE
#define BUTTONPORTCLOCK RCC_APB2Periph_GPIOE
int main(void)
{
	RCC_APB2PeriphClockCmd(LEDPORTCLK|LEDPORTCLK_1,ENABLE);	//ENABLE CLOCK cho GPIOC va GPIOD
	
	GPIO_InitTypeDef GPIO_InitStructure;										
  GPIO_InitStructure.GPIO_Pin = LED1|LED2;		
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;				//Output, tro keo
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;				//Clock GPIO 50Mhz
  GPIO_Init(LEDPORT, &GPIO_InitStructure);								//Cai dat GPIOC

	GPIO_InitStructure.GPIO_Pin = LED3|LED4;								//Cai dat GPIOD
	GPIO_Init(LEDPORT_1, &GPIO_InitStructure);
	
	RCC_APB2PeriphClockCmd(BUTTONPORTCLOCK,ENABLE);	         //ENABLE CLOCK cho GPIOE
	GPIO_InitStructure.GPIO_Pin = BUTTON1|BUTTON2|BUTTON3|BUTTON4;		
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;		 //Input floating
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;				 //Clock GPIO 50Mhz
  GPIO_Init(BUTTONPORT, &GPIO_InitStructure);							 //Cai dat GPIOE

	while(1)
	{
		if(!GPIO_ReadInputDataBit(BUTTONPORT,BUTTON1))				//Neu cong tac 1 nhan 
		{		
			GPIO_SetBits(LEDPORT, LED1); 												//Bat LED1
			Delay(0xFFFFF);
			GPIO_ResetBits(LEDPORT,LED1);												//Tat LED1
			Delay(0xFFFFF);
		}
		if(!GPIO_ReadInputDataBit(BUTTONPORT,BUTTON2))
		{
			GPIO_SetBits(LEDPORT, LED2); 
			Delay(0xFFFFF);
			GPIO_ResetBits(LEDPORT,LED2);
			Delay(0xFFFFF);
		}
		if(!GPIO_ReadInputDataBit(BUTTONPORT,BUTTON3))
		{
			GPIO_SetBits(LEDPORT_1, LED3); 
			Delay(0xFFFFF);
			GPIO_ResetBits(LEDPORT_1,LED3);
			Delay(0xFFFFF);
		}
		if(!GPIO_ReadInputDataBit(BUTTONPORT,BUTTON4))
		{
			GPIO_SetBits(LEDPORT_1, LED4); 
			Delay(0xFFFFF);
			GPIO_ResetBits(LEDPORT_1,LED4);
			Delay(0xFFFFF);
		}
	}
 return 0;
}
void Delay(unsigned int tick)
{
	while(tick) tick--;
}