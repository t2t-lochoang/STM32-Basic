#ifndef _SPI_MCP3208_H_
#define _SPI_MCP3208_H_  
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"


#define SPI_RCC_PORT  RCC_APB2Periph_GPIOA
#define SPI_GPIO_PORT GPIOA
     
#define SCK           GPIO_Pin_5     //SCK
#define MISO          GPIO_Pin_6     //MISO
#define MOSI			    GPIO_Pin_7     //MOSI

#define SPI_CS_PORT       GPIOB
#define SPI_RCC_CS_PORT   RCC_APB2Periph_GPIOB
#define CS_PIN            GPIO_Pin_0    //PB0  

/* Select SPI FLASH: ChipSelect pin low  */
#define Select_Flash()       GPIO_ResetBits(SPI_CS_PORT, CS_PIN)
/* Deselect SPI FLASH: ChipSelect pin high */
#define NotSelect_Flash()    GPIO_SetBits(SPI_CS_PORT, CS_PIN)
unsigned int MCP3208_Read(char Chanel,char Single);
u8 SPI_SendByte(u8 byte);	
void SPI_MCP3208_Init(void);
#endif

