/********************(C)COPYRIGHT 2010 lochoangvan@gmail.com********************

* Description: Bootloader by HoangLoc
* Guide:       Tartget => choose chip to build ex:STM32F103VE-> build
*/ 
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdlib.h>
#include <stdio.h>
#include "usart.h"
#include "float.h"
#include "stm32f10x_spi.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_flash.h"
#include "stm32f10x_iwdg.h"
#include "SPI_MCP3208.h"
#include "utils.h"
#include "led.h"
float ADC_Value;
char ch;
char temp[20],chanel;
char led_val = 0;
int main(void)
{
	RCC_Configuration();
  setup_delay_timer(TIM2);
	SPI_MCP3208_Init();
	Usart1Init(9600);
	LED_Configuration();
	USART1PutString("heello");
  while (1)
  {	
		delay_ms(1000);
		if(ch >=0x30 && ch <=0x37)		chanel = ch - 0x30;
		led_val = 1 - led_val;
		GPIO_WriteBit(LEDPORT,LED1,led_val);
		ADC_Value = MCP3208_Read(chanel,1);
		sprintf(temp,"Chanel %d: %d\n",chanel,ADC_Value);
		USART1PutString(temp);			
	}
}

char calculate_checksum(char input[],unsigned char len)
{
	unsigned char i;
	unsigned int sum;
	sum = input[0];                                       //take first data of array
	for(i = 1; i< len;i++) sum += input[i];               //Calculate sum value of Array data 
	sum = (char)(~sum)+0x01;                              //invert all bit and plus one
	return sum;
}
void IWDG_setup(void)
{
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	IWDG_SetPrescaler(IWDG_Prescaler_256); //Period = 256/LSI = 256/40Khz = 6,4ms
	IWDG_SetReload(50); //Reload every 50 * 6.4ms = 320ms
	IWDG_ReloadCounter(); //Use to reload -> prevent reset
	IWDG_Enable();
}
void RCC_Configuration(void)
{
	//	  SystemInit();
	ErrorStatus HSEStartUpStatus;
	/* SYSCLK, HCLK, PCLK2 and PCLK1 configuration -----------------------------*/   
	/* RCC system reset(for debug purpose) */
	RCC_DeInit();
	/* Enable HSE */
	RCC_HSEConfig(RCC_HSE_ON);
	/* Wait till HSE is ready */
	HSEStartUpStatus = RCC_WaitForHSEStartUp();
	if (HSEStartUpStatus == SUCCESS)
	{
		/* Enable Prefetch Buffer */
		FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

		/* Flash 2 wait state */
		FLASH_SetLatency(FLASH_Latency_2);
 
		/* HCLK = SYSCLK */
		RCC_HCLKConfig(RCC_SYSCLK_Div1); 
  
 		/* PCLK2 = HCLK */
		RCC_PCLK2Config(RCC_HCLK_Div1); 

		/* PCLK1 = HCLK/2 */
		RCC_PCLK1Config(RCC_HCLK_Div2);

		/* PLLCLK = 8MHz * 9 = 72 MHz */
    	RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);

		/* Enable PLL */ 
		RCC_PLLCmd(ENABLE);

		/* Wait till PLL is ready */
		while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
		{
		}

		/* Select PLL as system clock source */
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

		/* Wait till PLL is used as system clock source */
		while(RCC_GetSYSCLKSource() != 0x08)		{		}

	}else
	{ 
		RCC_DeInit();
		 /***************HSI CLOCK****************/
	//TURN ON HSI AND SET IT AS SYSCLK SRC
	//SETUP THE SYSTEM CLOCK AS BELOW
	//CLOCK SRC = 8MHZ HSI + PLL
	//SYSCLK = 64MHZ
	//HCLK = SYSCLK = 64MHZ
	//PCLK2 = HCLK = 64MHZ
	//PCLK1 = HCLK = 32MHZ

	//	//TURN ON HSI AND SET IT AS SYSCLK SRC
		RCC_HSICmd(ENABLE);
		while(RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET){};

		//SET HSI AS SYSCLK SRC. CONFIGURE HCLK, PCLK1 & PCLK2
		RCC_SYSCLKConfig(RCC_SYSCLKSource_HSI);
		RCC_HCLKConfig(RCC_SYSCLK_Div1);
		RCC_PCLK1Config(RCC_HCLK_Div1);
		RCC_PCLK2Config(RCC_HCLK_Div1);
		//SET THE FLASH LATENCY AS PER OUR CLOCK
		//FASTER THE CLOCK, MORE LATENCY THE FLASH NEEDS
		//000 Zero wait state, if 0  MHz < SYSCLK <= 24 MHz
		//001 One wait state, if  24 MHz < SYSCLK <= 48 MHz
		//010 Two wait states, if 48 MHz < SYSCLK <= 72 MHz */
		FLASH_SetLatency(FLASH_Latency_2);

		//DISABLE PLL
		RCC_PLLCmd(DISABLE);
		//CHANGE PLL SRC AND MULTIPLIER
		RCC_PLLConfig(RCC_PLLSource_HSI_Div2, RCC_PLLMul_16);
		//ENABLE PLL
		//WAIT FOR IT TO BE READY
		//SET SYSCLK SRC AS PLLCLK
		RCC_PLLCmd(ENABLE);
		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET){};
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
		FLASH_SetLatency(FLASH_Latency_2);
		//SET HCLK = SYSCLK = 64MHZ
		RCC_HCLKConfig(RCC_SYSCLK_Div1);
		//SET PCLK2 = HCLK = 64MHZ
		RCC_PCLK2Config(RCC_HCLK_Div1);

		//SET PCLK1 = HCLK/2 = 32MHZ
		RCC_PCLK1Config(RCC_HCLK_Div2);
	}
}


#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param file: pointer to the source file name
  * @param line: assert_param error line source number
  * @retval : None
  */



void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif



/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
