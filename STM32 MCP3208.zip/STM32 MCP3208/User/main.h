#ifndef _MAIN_H_
#define _MAIN_H_
#include "stm32f10x.h"
void RCC_Configuration(void);
#endif
