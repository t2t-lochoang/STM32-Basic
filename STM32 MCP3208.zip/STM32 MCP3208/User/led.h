#ifndef _LED_H_
#define _LED_H_
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
void LED_Configuration(void);
void LED_ON(unsigned char led);
void LED_OFF(unsigned char led);
void LED_ALL_ON(void);
void LED_ALL_OFF(void);
//Define for LED
#define LED1 						GPIO_Pin_6			
#define LED2 						GPIO_Pin_7
#define LED3 						GPIO_Pin_6
#define LED4 						GPIO_Pin_13

#define LEDPORT					GPIOC
#define LEDPORT_1				GPIOD
#define LEDPORTCLK			RCC_APB2Periph_GPIOC
#define LEDPORTCLK_1		RCC_APB2Periph_GPIOD
//Define for BUTTON
#define BUTTON1 				GPIO_Pin_2			
#define BUTTON2 				GPIO_Pin_3
#define BUTTON3 				GPIO_Pin_4
#define BUTTON4 				GPIO_Pin_5

#define BUTTONPORT			GPIOE
#define BUTTONPORTCLOCK RCC_APB2Periph_GPIOE
#endif
