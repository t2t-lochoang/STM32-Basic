import messages_pb2
import serial
import msg_pad
import os
sensor_in = messages_pb2.Sensor()
ser = serial.Serial('COM3',115200, timeout = 3, parity = serial.PARITY_NONE, rtscts=1)
data_in = []
data = []
msg_id = 0
while True:
    data_in = ser.read(2)
    if len(data_in) > 1 and data_in[0] == ord('?') and data_in[1] == ord('#'):
        size_buf = ser.read(6)
        data = ser.read((size_buf[2] << 24) | (size_buf[3] << 16) | (size_buf[4] << 8) | size_buf[5])
        sensor_in.ParseFromString(data)
        os.system('cls')
        print(f"Value ADC1: {sensor_in.data[0]}mV Value ADC2: {sensor_in.data[1]}mV")
        print(f"Status: {sensor_in.status}")
        print(f"Message: {sensor_in.message}")
        sensor_out = messages_pb2.Sensor()
        if sensor_in.data[0] > 3000 or sensor_in.data[1] > 3000:
            sensor_out.command = True
            size = sensor_out.ByteSize()
            data = sensor_out.SerializeToString()
            msg_data = msg_pad.Combine(30,data)
            msg = msg_data.get_data()  # add data to send data
            print(f"Sent command Turn On LED")
            ser.write(msg)
        else:
            sensor_out.command = False
            size = sensor_out.ByteSize()
            data = sensor_out.SerializeToString()
            msg_data = msg_pad.Combine(30,data)
            msg = msg_data.get_data()  # add data to send data
            ser.write(msg)
