######################
class Combine(object):
    def __init__(self, msg_id, data_in):
        self.msg_id = msg_id
        self.data_in = data_in
        self.msg_out_end = 0
        self.msg_out_cur = 0
        self.buffer_final = []
        self.msg_size = 0
    def msg_out_append(self, ch):
        if self.msg_out_cur == 0:
            self.buffer_final.insert(self.msg_out_end * 64,ord('?'))
#            print(f"msg_out_end: {self.msg_out_end}")
            self.msg_out_cur = 1
        self.buffer_final.insert(self.msg_out_end * 64 + self.msg_out_cur, ch)
        self.msg_out_cur += 1
        if self.msg_out_cur == 64:
            self.msg_out_cur = 0
            self.msg_out_end = self.msg_out_end + 1
    def msg_out_pad(self):
        if self.msg_out_cur == 0:
             exit(0)
        while self.msg_out_cur < 64:
            self.buffer_final.insert(self.msg_out_end * 64 + self.msg_out_cur,0)
            self.msg_out_cur += 1
        self.msg_out_cur = 0
        self.msg_out_end = self.msg_out_end + 1
        self.msg_out_end = self.msg_out_end + 1
    def get_data(self):
        self.msg_size = len(self.data_in)
        self.msg_out_append(ord('#'))
        self.msg_out_append((self.msg_size >> 8) & 0xFF)
        self.msg_out_append(self.msg_id & 0xFF)
        self.msg_out_append((self.msg_size >> 24) & 0xFF)
        self.msg_out_append((self.msg_size >> 16) & 0xFF)
        self.msg_out_append((self.msg_size >> 8)  & 0xFF)
        self.msg_out_append(self.msg_size & 0xFF)
        for i in self.data_in:
            self.msg_out_append(i)
        self.msg_out_pad()
        return self.buffer_final
