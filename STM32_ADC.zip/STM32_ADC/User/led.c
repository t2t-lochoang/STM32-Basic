#include "led.h"

void LEDInit(void)
{
	RCC_APB2PeriphClockCmd(LEDPORTCLK|LEDPORTCLK_1,ENABLE);	//ENABLE CLOCK cho GPIOC va GPIOD
	RCC_APB2PeriphClockCmd(BUTTONPORTCLOCK,ENABLE);	   
	GPIO_InitTypeDef GPIO_InitStructure;										
  GPIO_InitStructure.GPIO_Pin = LED1|LED2;		
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;				//Output, tro keo
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;				//Clock GPIO 50Mhz
  GPIO_Init(LEDPORT, &GPIO_InitStructure);								//Cai dat GPIOC

	GPIO_InitStructure.GPIO_Pin = LED3|LED4;								//Cai dat GPIOD
	GPIO_Init(LEDPORT_1, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = BUTTON1|BUTTON2|BUTTON3|BUTTON4;		
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;		 //Input floating
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;				 //Clock GPIO 50Mhz
 GPIO_Init(BUTTONPORT, &GPIO_InitStructure);							 //Cai dat GPIOE
} 
void LED_ON(unsigned char led)
{
	switch(led)
	{
		case 1: GPIO_SetBits(LEDPORT,LED1);break;
		case 2: GPIO_SetBits(LEDPORT,LED2);break;
		case 3: GPIO_SetBits(LEDPORT_1,LED3);break;
		case 4: GPIO_SetBits(LEDPORT_1,LED4);break;
	}
}
void LED_OFF(unsigned char led)
{
	switch(led)
	{
		case 1: GPIO_ResetBits(LEDPORT,LED1);break;
		case 2: GPIO_ResetBits(LEDPORT,LED2);break;
		case 3: GPIO_ResetBits(LEDPORT_1,LED3);break;
		case 4: GPIO_ResetBits(LEDPORT_1,LED4);break;
	}
}
void LED_ALL_ON(void)
{
	GPIO_SetBits(LEDPORT,LED1|LED2);
	GPIO_SetBits(LEDPORT_1,LED3|LED4);
}
void LED_ALL_OFF(void)
{
	GPIO_ResetBits(LEDPORT,LED1|LED2);
	GPIO_ResetBits(LEDPORT_1,LED3|LED4);
}

