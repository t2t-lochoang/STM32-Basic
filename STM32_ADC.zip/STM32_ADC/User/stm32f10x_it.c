/**
  ******************************************************************************
  * @file    USART/Interrupt/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
	
  *          interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 


#include "stm32f10x_usart.h"
#include "usart.h"
#include "led.h"
#include <string.h>

/** @addtogroup STM32F10x_StdPeriph_Examples
  * @{
  */

/** @addtogroup USART_Interrupt
  * @{
  */ 


/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  NVIC_SystemReset();
  while (1)
  {
  }
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  NVIC_SystemReset();
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  NVIC_SystemReset();
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  NVIC_SystemReset();
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSV_Handler exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

////////////////////////////////////////////////////////////////////////////////

/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
char usart1_buff[30];
unsigned char count = 0;
void USART1_IRQHandler(void)
{
		if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) != RESET)
		{
			if(count<29)
			{
				usart1_buff[count] =  USART_ReceiveData(USART1);
				if(usart1_buff[count]=='\r')
				{
					if(strstr(usart1_buff,"LED1ON") != NULL)
					{
						LED_ON(1);
						USART1PutString("LED1 is ON\r\n");
					}
					else if(strstr(usart1_buff,"LED2ON")!= NULL)
					{
						LED_ON(2);
						USART1PutString("LED2 is ON\r\n");
					}
					else if(strstr(usart1_buff,"LED3ON")!= NULL) 
					{
						LED_ON(3);
						USART1PutString("LED3 is ON\r\n");
					}
					else if(strstr(usart1_buff,"LED4ON")!= NULL) 
					{
						LED_ON(4);
						USART1PutString("LED4 is ON\r\n");
					}
					else if(strstr(usart1_buff,"LED1OFF")!= NULL) 
					{
						LED_OFF(1);
						USART1PutString("LED1 is OFF\r\n");
					}
					else if(strstr(usart1_buff,"LED2OFF")!= NULL) 
					{
						LED_OFF(2);
						USART1PutString("LED2 is OFF\r\n");
					}
					else if(strstr(usart1_buff,"LED3OFF")!= NULL) 
					{
						LED_OFF(3);
						USART1PutString("LED3 is OFF\r\n");
					}
					else if(strstr(usart1_buff,"LED4OFF")!= NULL) 
					{
						LED_OFF(4);
						USART1PutString("LED4 is OFF\r\n");
					}else if(strstr(usart1_buff,"ALLON")!= NULL) 
					{
						LED_ALL_ON();
						USART1PutString("All LED is on\r\n");
					}
					else if(strstr(usart1_buff,"ALLOFF")!= NULL) 
					{
						LED_ALL_OFF();
						USART1PutString("All LED is off\r\n");
					}else USART1PutString("Wrong command!\r\n");
					count = 0;																		//Reset counter
				}
				count++;
			}else count = 0; 																	//RESET counter
		}
}
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 

/**
  * @}
  */ 
/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/

