#include "misc.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_adc.h"
#include "led.h"
#include "usart.h"
#include "stdio.h"
void ADCInit(void);
unsigned int Voltage_1 = 0;  
unsigned int Voltage_2 = 0;
unsigned int tick_delay = 0xFFF;
unsigned int tick_pwm1 = 0;
unsigned int tick_pwm2 = 0;
unsigned int tick_usart = 0xFFFF;
int main(void)
{
	LEDInit();
	Usart1Init(115200);
	ADCInit();
	printf("ADC demo code by Hoang Loc\r\n");
	while(1)
	{		
		/*Send data in period time*/
		if(tick_usart == 0)		
		{
			printf("Voltage Chanel1 = %dmV  Chanel2 = %dmV \r\n",Voltage_1,Voltage_2);
			tick_usart = 0xFFFF;			
		}
		tick_usart--;	
		
		if(tick_delay == 0)			
		{
			ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 1, ADC_SampleTime_55Cycles5);	//Set kenh 11 de doc
			Voltage_1 = 3300*ADC_GetConversionValue(ADC1)/4095;	 													//Conver to mV		
			tick_pwm1 = (unsigned int) (Voltage_1 * 4095 / 3300);                         //Chuyen doi gia tri ADC1 ra pwm1 delay				
			tick_delay = 0xFFF;
		}
		if(tick_delay ==0x0F) 
		{
			ADC_RegularChannelConfig(ADC1, ADC_Channel_10, 1 , ADC_SampleTime_55Cycles5);//Set kenh 10 de doc
			Voltage_2 = 3300*ADC_GetConversionValue(ADC1)/4095;														//Conver to mV
			tick_pwm2 = (unsigned int) (Voltage_2 * 4095 / 3300);                          //Chuyen doi gia tri ADC2 ra pwm2 delay
		}
		if(tick_delay == 0xFFF)
		{
			GPIO_ResetBits(LEDPORT,LED1);												//Tat LED1
		  GPIO_ResetBits(LEDPORT,LED2);
			GPIO_ResetBits(LEDPORT_1,LED3);
			GPIO_ResetBits(LEDPORT_1,LED4);
		}
	 if(tick_delay == tick_pwm1) 
		{
			GPIO_SetBits(LEDPORT, LED1); 												//Bat LED1
			GPIO_SetBits(LEDPORT, LED2); 
	  }
		if(tick_delay == tick_pwm2) 
		{
			GPIO_SetBits(LEDPORT_1, LED3);											//Bat LED2
			GPIO_SetBits(LEDPORT_1, LED4);
		}	
		tick_delay--;
	}
 return 0;
}
void ADCInit(void)
{
	ADC_InitTypeDef ADC_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
	 /* Enable ADC1 and GPIOC clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_GPIOC, ENABLE);
	
  /* Configure PC.01 (ADC Channel14) as analog input -------------------------*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	 /* Configure PC.0 (ADC Channel14) as analog input -------------------------*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	 /* ADC1 configuration ------------------------------------------------------*/
  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_InitStructure.ADC_ScanConvMode = ENABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
  ADC_InitStructure.ADC_NbrOfChannel = 1;
  ADC_Init(ADC1, &ADC_InitStructure);

  /* Enable ADC1 DMA */
  ADC_DMACmd(ADC1, ENABLE);
  
  /* Enable ADC1 */
  ADC_Cmd(ADC1, ENABLE);

  /* Enable ADC1 reset calibaration register */   
  ADC_ResetCalibration(ADC1);
  /* Check the end of ADC1 reset calibration register */
  while(ADC_GetResetCalibrationStatus(ADC1));

  /* Start ADC1 calibaration */
  ADC_StartCalibration(ADC1);

  /* Check the end of ADC1 calibration */
  while(ADC_GetCalibrationStatus(ADC1));
     
  /* Start ADC1 Software Conversion */ 
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}
