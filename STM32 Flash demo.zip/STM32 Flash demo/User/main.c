#include "stdio.h"
#include "misc.h"
#include "stm32f10x_exti.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_flash.h"
#include "stm32f10x_usart.h"
#include "usart.h"
#define Internal_Flash_Start_Addr 0x800F800 
void USART1_IRQHandler(void);
void Write_Buff_To_InternalFlash(u8 data_in[],u32 start_addr,unsigned int len);
u32 Readflash(u32 addr);
void Read_Buff_From_InternalFlash(u8 data_out[],u32 start_addr,unsigned int len);
char usart1_buff[100];
char flash_internal_buff[100];
unsigned char count = 0;
int main(void)
{
	Usart1Init(115200);
	printf("FLASH demo code by Hoang Loc\r\n");
	
	while(1)
	{		
		
	}
 return 0;
}
void Delay(unsigned int tick)
{
	while(tick--);
}
void USART1_IRQHandler(void)
{
		if(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) != RESET)
		{
			if(count<100)
			{
				usart1_buff[count] =  USART_ReceiveData(USART1);
         if(usart1_buff[count]==0x0A)
				 {
					printf("Write data %d byte data to 0x%x adress...",count,Internal_Flash_Start_Addr);
					Write_Buff_To_InternalFlash(usart1_buff,Internal_Flash_Start_Addr,count);
					USART1PutString("done!\r\n");
					printf("Read data %d byte data from 0x%x adress...",count,Internal_Flash_Start_Addr);
					memset(flash_internal_buff,'\0',100);				//Reset arrray 
					Read_Buff_From_InternalFlash(flash_internal_buff,Internal_Flash_Start_Addr,count);
					USART1PutString("done!\r\n");
					USART1PutString("Data send back:\r\n");
					
					USART1PutString(flash_internal_buff);
					USART1PutString("\r\n");
					count = 0;                                  //Reset counter
				}	else {
					if(usart1_buff[count]!=0x0D)	count++;      //Don't add 0x0D
				}	
			}else count = 0; 															  //RESET counter
		}
}
void Write_Buff_To_InternalFlash(u8 data_in[],u32 start_addr,unsigned int len)
{
	unsigned int i;

	if((start_addr - 0x8000000)%0x800==0)                    //Erase new page if data locate at new page
	{
		FLASH_UnlockBank1();
		FLASH_ErasePage(start_addr);
	}	
	for(i = 0;i<len;i++)	FLASH_ProgramWord(start_addr+4*i, data_in[i]);
}	
void Read_Buff_From_InternalFlash(u8 data_out[],u32 start_addr,unsigned int len)
{
	unsigned int i;
	for(i = 0;i<len;i++ ) data_out[i] = (unsigned char)(Readflash(start_addr+4*i));
}
u32 Readflash(u32 addr)
{
	u32* data = (u32*)(addr);	
	return *data;
}
