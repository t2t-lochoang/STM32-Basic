/*
 * usart.h
 */

#ifndef _USART_H_
#define _USART_H_
#include "STM32f10x.h"
#include <stdio.h>
void Usart1Init(unsigned int speed);
uint32_t Usart1GetChar(char *ch);
uint32_t Usart1PutChar(char ch);
void  USART1PutString( const char * const pcString);
void vUART1InterruptHandler( void );
void Usart2Init(unsigned int speed);
uint32_t Usart2GetChar(char *ch);
uint32_t Usart2PutChar(char ch);
void  USART2PutString( const char * const pcString);
void USART2_IRQHandler( void );

#endif /* USART_H_ */
