#include "stm32f10x_tim.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_usart.h"
#include "usart.h"
#include "utils.h"
#include "DHT.h"
extern DHT_data_struct DHT12_data;
int main(void)
{
	Usart2Init(115200);
	printf("DHT12 Demo code by HoangLoc\n");
	setup_delay_timer(TIM2);
	DHT12_Init();
	
	while(1)
	{	
		DHT12_READ();
		printf("Temperature:%0.1f  Humility:%0.1f \r\n",DHT12_data.Temprature/10.0,DHT12_data.Humility/10.0);
		delay_ms(1000);
	}
 return 0;
}
