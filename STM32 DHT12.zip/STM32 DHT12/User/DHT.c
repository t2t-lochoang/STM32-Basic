#include "DHT.h"
#include <stdio.h>
#include "sys.h"
#include "utils.h"
#include "stm32f10x_gpio.h"
#define SEND_SDA   PAout(12)
#define READ_SDA   PAin(12) 
unsigned char Sensor_AnswerFlag=0;
unsigned char Sensor_ErrorFlag;
DHT_data_struct DHT12_data; 
GPIO_InitTypeDef GPIO_InitStructure;

void DHT12_Init(void)
{					     
	RCC_APB2PeriphClockCmd(	RCC_APB2Periph_GPIOA, ENABLE );
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11|GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD ;  
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);	
	GPIO_ResetBits(GPIOA,GPIO_Pin_11); 
	delay_ms(2000);
	GPIO_ResetBits(GPIOA,GPIO_Pin_12); 
}
void SDA_IN(void)
{
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING ;   
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}
void SDA_OUT(void)
{
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD ;  
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}
unsigned char DHT12_Rdata(void)
{
	unsigned char i;
	u16 j;
	unsigned char data=0,bit=0;
	for(i=0;i<8;i++)
	{
		while(!READ_SDA)
		{
			if(++j>=50000)	break;
		}
		delay_us(30);
		bit=0;
		if(READ_SDA)	bit=1;
		j=0;
		while(READ_SDA)	
		{
			if(++j>=50000)	break;					
		}
		data<<=1;
		data|=bit;
	}
	return data;
}
unsigned char DHT12_READ(void)
{
	unsigned int j;
	unsigned char temp,Humi_H,Humi_L,Temp_H,Temp_L,Temp_CAL;
	SDA_OUT(); 
	SEND_SDA = 0;
	delay_ms(20);
	SEND_SDA=1;	 
	SDA_IN();	
	delay_us(30);

	Sensor_AnswerFlag=0;

	if(READ_SDA==0)
	{
		Sensor_AnswerFlag=1;	
		j=0;
		while((!READ_SDA)) 
		{
			if(++j>=500) 
			{
				Sensor_ErrorFlag=1;
				break;
			}
		}
		j=0;
		while(READ_SDA)
		{
			if(++j>=800) 
			{
				Sensor_ErrorFlag=1;
				break;
			}		
		}
		Humi_H=DHT12_Rdata();
		Humi_L=DHT12_Rdata();
		Temp_H=DHT12_Rdata();	
		Temp_L=DHT12_Rdata();
		Temp_CAL=DHT12_Rdata();
		temp=(unsigned char)(Humi_H+Humi_L+Temp_H+Temp_L);
		if(Temp_CAL==temp)
		{
			DHT12_data.Humility=Humi_H*10+Humi_L; 
	
			if(Temp_L&0X80)	
			{
				DHT12_data.Temprature =0-(Temp_H*10+((Temp_L&0x7F)));
			}
			else 
			{
				DHT12_data.Temprature=Temp_H*10+Temp_L;
			}
			if(DHT12_data.Humility>950) 
			{
			  DHT12_data.Humility=950;
			}
			if(DHT12_data.Humility<200)
			{
				DHT12_data.Humility =200;
			}
			if(DHT12_data.Temprature>600)
			{
			  DHT12_data.Temprature=600;
			}
			if(DHT12_data.Temprature<-200)
			{
				DHT12_data.Temprature = -200;
			}
		}
		else
		{
		 return 0;
		}
	}
	else
	{
		Sensor_ErrorFlag=0; 
	}
	return 1;
}




