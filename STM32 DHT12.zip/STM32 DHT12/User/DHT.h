#ifndef _DHT_H_
#define _DHT_H_
void DHT12_Init(void);
unsigned char DHT12_Rdata(void);
unsigned char DHT12_READ(void);
typedef struct
{
	int Temprature;
	unsigned int Humility;
}DHT_data_struct;

#endif 
