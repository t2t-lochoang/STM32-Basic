/*
 * usart.h
 */

#ifndef _USART_H_
#define _USART_H_
#include "STM32f10x.h"
#include <stdio.h>
void Usart1Init(unsigned int speed);
void Usart1PutChar(char ch);
void USART1PutString( const char * const pcString);
void Usart2Init(unsigned int speed);
void Usart2PutChar(char ch);
void USART2PutString( const char * const pcString);
void Usart3PutChar(char ch);
void USART3PutString( const char * const pcString);


#endif /* USART_H_ */
